var element1 = document.querySelector(".peersli1");
var element2 = document.querySelector(".peersli2");

element1.addEventListener('click', () => {
    element1.remove();
  });
  element2.addEventListener('click', () => {
    element2.remove();
  });

  var button = document.querySelector(".edit");
  var name1 = document.querySelector("#username");

  function switchName() {
    name1.innerText = "Lazy Coder";
  };