let product = 1;

for (var i = 1; i <= 12; i++) {
  console.log('*');
  console.log(i);
  product *= i;
};

console.log('=' + ' ' + product);