let sum = 0;

for (var i = 0; i <= 100; i++) {
        console.log(i)
        console.log(sum += i);
};


let num = 0

for (var i = 1; i <= 100; i++) {
    do {
    num += i;
  }
  while (i > 100);

  console.log(i)
  console.log("+")
};

console.log(num)