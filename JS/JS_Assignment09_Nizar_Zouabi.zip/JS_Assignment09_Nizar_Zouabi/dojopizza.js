function pizzaOven(crustType,sauceType,cheeses,toppings) {
    var pizza = {};
    pizza.crustType = crustType;
    pizza.sauceType = sauceType;
    pizza.cheeses = cheeses;
    pizza.toppings = toppings;
    return pizza;
};

var pizza0 = pizzaOven("deep dish","traditional",["mozzarella"],["pepperoni", "sausage"]);
console.log(pizza0);

var pizza1 = pizzaOven("hand tossed","marinara",["mozzarella", "feta"],["mushrooms", "olives", "onions"]);
console.log(pizza1);

var pizza2 = pizzaOven("sleepy","marinara",["mozzarellaa", "fatfeta"],["mushrooms", "olives", "tor"]);
console.log(pizza2);

var pizza3 = pizzaOven("hand tossed","marinara",["mozzarellaaa", "fatfetaa"],["mushrooms", "olives", "rutor"]);
console.log(pizza3);
