console.log("page loaded...");

var vid = document.getElementsByClassName("video-small")

function resetVideo(){
};