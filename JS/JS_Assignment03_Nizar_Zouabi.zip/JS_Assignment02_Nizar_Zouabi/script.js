function addCount() {
    var count0 = document.querySelector("#count0");
    var value = count0.innerHTML;
    ++value;
    
    document.querySelector("#count0").innerHTML = value;
    };

    function addCount1() {
        var count1 = document.querySelector("#count1");
        var value = count1.innerHTML;
        ++value;
        
        document.querySelector("#count1").innerHTML = value;
        };

        function addCount2() {
            var count2 = document.querySelector("#count2");
            var value = count2.innerHTML;
            ++value;
            
            document.querySelector("#count2").innerHTML = value;
            };