var y = document.querySelector("count");

function addCount(){
  count.innerHTML = "4 like(s)"
};