
let hots = document.querySelectorAll(".hot");
let colds = document.querySelectorAll(".cold");
let hotTempsF = ['75°', '80°', '69°', '78°'];
let coldTempsF = ['65°', '66°', '61°', '70°'];
let hotTempsC = ['24°', '27°', '21°', '26°'];
let coldTempsC = ['18°', '19°', '16°', '21°'];

document.getElementById("selector").addEventListener("change", function () {
    var selectedValue = this.value;
    if (selectedValue == "0") {
        switCh("C");
    }
    else{
        switCh("F");
    }

});

function switCh(unit) {
    if(unit == "C"){
        for(let i = 0; i < hots.length; i++){
            hots[i].innerText = hotTempsC[i];
        }
        for(let i = 0; i < colds.length; i++){
            colds[i].innerText = coldTempsC[i];
        }
    }
    else{
        for(let i = 0; i < hots.length; i++){
            hots[i].innerText = hotTempsF[i];
        }
        for(let i = 0; i < colds.length; i++){
            colds[i].innerText = coldTempsF[i];
        }
    }

};

window.onload = ()=> {
    switCh("C");
}

function alertOn() {
    (alert('Loading weather report...'));
};

var nodeParent = document.querySelector('.cookies-popup');
var nodeChild = document.querySelector('#btn');

nodeChild.addEventListener('click', () => {
  nodeParent.remove();
});