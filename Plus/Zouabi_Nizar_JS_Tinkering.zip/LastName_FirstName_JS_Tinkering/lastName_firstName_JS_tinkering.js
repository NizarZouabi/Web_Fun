let minHeight = 52

const displayIfChildIsAbleToRideTheRollerCoaster = (childHeight) => {
    if (childHeight >= minHeight) {
        console.log("Get on that ride, kiddo!")
    } else {
        console.log("Sorry kiddo. Maybe next year")
    };
};

displayIfChildIsAbleToRideTheRollerCoaster(54)